# SariSari POS — Vercel starter

This is a Vercel-compatible **starter**, not a full conversion of the existing Python POS. It provides a small mobile-friendly PWA shell and server-side Neon/Postgres account setup/login APIs. Product, sales, barcode, reports, and migration of existing SQLite data still need to be ported and tested before real-store use.

## Required environment variables in Vercel
- `DATABASE_URL`: Neon pooled or direct Postgres connection string (keep secret)
- `SESSION_SECRET`: a long random secret (32+ characters)

## Database setup
In Neon SQL Editor, run the complete contents of `schema.sql`.

## First admin
Open `/setup` on the deployed site and create the first admin. This endpoint refuses setup after any account exists. Do not share your passwords or DATABASE_URL.

## Deploy from phone
1. Upload this project to a private GitHub repository (Vercel's normal Git deployment expects a Git repository; it does not deploy arbitrary ZIP files directly in every workflow).
2. In Vercel, import that repository.
3. Add `DATABASE_URL` and `SESSION_SECRET` in Project Settings → Environment Variables.
4. Deploy, then run `schema.sql` in Neon before using setup.

## Important
This starter does not include the old POS's data or complete checkout workflow. Do not use it for live sales until product/sales features are ported and tested. `DATABASE_URL` is a server-only secret and must never be put in `NEXT_PUBLIC_*`.
