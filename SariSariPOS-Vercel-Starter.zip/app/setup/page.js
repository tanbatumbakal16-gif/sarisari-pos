 "use client";
import { useState } from "react";
export default function Setup() {
  const [username,setUsername]=useState(""); const [password,setPassword]=useState(""); const [msg,setMsg]=useState("");
  async function submit(e){e.preventDefault();setMsg("Creating account…");const r=await fetch("/api/auth/setup",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username,password})});const d=await r.json();setMsg(r.ok?"Admin created. You can now log in.":(d.error||"Setup failed"));}
  return <main className="wrap"><h1>Create admin</h1><form className="panel" onSubmit={submit}><label>Username<input autoComplete="username" minLength="3" maxLength="40" required value={username} onChange={e=>setUsername(e.target.value)}/></label><label>Password<input type="password" autoComplete="new-password" minLength="10" required value={password} onChange={e=>setPassword(e.target.value)}/></label><button className="button">Create admin account</button><p>{msg}</p><a href="/">Home</a></form></main>;
}
