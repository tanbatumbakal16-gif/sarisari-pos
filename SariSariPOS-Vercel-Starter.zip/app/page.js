export default function Home() {
  return <main className="wrap">
    <div className="brand">S</div>
    <h1>SariSari POS</h1>
    <p className="muted">Online store dashboard starter</p>
    <div className="panel">
      <h2>Welcome</h2>
      <p>This is the Vercel-ready foundation. Admin setup and login APIs are included; the complete checkout and reporting features from the desktop app still need to be migrated.</p>
      <a className="button" href="/setup">Set up admin</a>
      <a className="button secondary" href="/login">Log in</a>
    </div>
    <p className="tiny">Install: open this site in Safari → Share → Add to Home Screen.</p>
  </main>;
}
