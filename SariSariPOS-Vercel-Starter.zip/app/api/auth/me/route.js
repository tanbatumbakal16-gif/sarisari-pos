import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { cookieName, readToken } from "@/lib/auth";
import { db } from "@/lib/db";
export const runtime = "nodejs";
export async function GET() {
 try { const token=cookies().get(cookieName)?.value; const p=token?await readToken(token):null; if(!p?.sub)return NextResponse.json({error:"Not logged in"},{status:401});
 const r=await db().query("SELECT id,username,role FROM users WHERE id=$1",[p.sub]); if(!r.rowCount)return NextResponse.json({error:"Not logged in"},{status:401});
 return NextResponse.json({user:r.rows[0]});
 } catch { return NextResponse.json({error:"Could not verify session."},{status:500}); }
}
