import { NextResponse } from "next/server";
import { db } from "@/lib/db";
export const runtime = "nodejs";
export async function GET() {
 try { const r=await db().query("SELECT COUNT(*)::int AS count FROM users"); return NextResponse.json({setup_required:r.rows[0].count===0}); }
 catch { return NextResponse.json({error:"Database is not configured or schema.sql has not been run."},{status:500}); }
}
