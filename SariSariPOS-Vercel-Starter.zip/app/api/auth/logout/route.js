import { NextResponse } from "next/server";
import { cookieName } from "@/lib/auth";
export async function POST() { const r=NextResponse.json({ok:true}); r.cookies.set(cookieName,"",{httpOnly:true,secure:process.env.NODE_ENV==="production",sameSite:"lax",path:"/",maxAge:0}); return r; }
