import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { makeToken, cookieName } from "@/lib/auth";
export const runtime = "nodejs";
export async function POST(req) {
 try {
  const {username,password}=await req.json();
  if(typeof username!=="string"||typeof password!=="string") return NextResponse.json({error:"Enter username and password."},{status:400});
  const r=await db().query("SELECT id,username,password_hash,role FROM users WHERE lower(username)=lower($1) LIMIT 1",[username.trim()]);
  if(!r.rowCount||!(await bcrypt.compare(password,r.rows[0].password_hash))) return NextResponse.json({error:"Invalid username or password."},{status:401});
  const u=r.rows[0], token=await makeToken(u), res=NextResponse.json({user:{id:u.id,username:u.username,role:u.role}});
  res.cookies.set(cookieName,token,{httpOnly:true,secure:process.env.NODE_ENV==="production",sameSite:"lax",path:"/",maxAge:8*60*60});
  return res;
 } catch { return NextResponse.json({error:"Login unavailable. Check database setup."},{status:500}); }
}
