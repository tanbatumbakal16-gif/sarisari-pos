import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
export const runtime = "nodejs";
export async function POST(req) {
 try {
  const {username,password}=await req.json();
  if(typeof username!=="string"||username.trim().length<3||username.length>40) return NextResponse.json({error:"Username must be 3–40 characters."},{status:400});
  if(typeof password!=="string"||password.length<10||password.length>200) return NextResponse.json({error:"Password must be at least 10 characters."},{status:400});
  const pool=db(); const client=await pool.connect();
  try {
   await client.query("BEGIN");
   const count=await client.query("SELECT COUNT(*)::int AS count FROM users");
   if(count.rows[0].count>0){await client.query("ROLLBACK");return NextResponse.json({error:"Admin setup is already complete."},{status:409});}
   const hash=await bcrypt.hash(password,12);
   const result=await client.query("INSERT INTO users(username,password_hash,role) VALUES($1,$2,'admin') RETURNING id,username,role",[username.trim(),hash]);
   await client.query("COMMIT");
   return NextResponse.json({user:result.rows[0]}, {status:201});
  } catch(e){await client.query("ROLLBACK");throw e;} finally {client.release();}
 } catch(e){return NextResponse.json({error:e.code==="23505"?"Username already exists.":"Setup failed. Check database configuration and schema."},{status:500});}
}
