import "./globals.css";
export const metadata = {
  title: "SariSari POS",
  description: "Sari-sari store point of sale",
  manifest: "/manifest.webmanifest",
  appleWebApp: { capable: true, statusBarStyle: "default", title: "SariSari POS" },
  viewport: "width=device-width, initial-scale=1, maximum-scale=1, viewport-fit=cover"
};
export default function RootLayout({ children }) {
  return <html lang="en"><body>{children}</body></html>;
}
