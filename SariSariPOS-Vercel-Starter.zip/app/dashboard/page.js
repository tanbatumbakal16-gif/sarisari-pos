 "use client";
import { useEffect, useState } from "react";
export default function Dashboard() {
 const [user,setUser]=useState(null); const [error,setError]=useState("");
 useEffect(()=>{fetch("/api/auth/me").then(r=>r.json().then(d=>{if(!r.ok)location.href="/login";else setUser(d.user)})).catch(()=>setError("Could not connect."));},[]);
 async function logout(){await fetch("/api/auth/logout",{method:"POST"});location.href="/login";}
 return <main className="wrap"><h1>SariSari POS</h1><section className="panel"><h2>Dashboard</h2><p>{user?"Signed in as "+user.username:"Checking session…"}</p>{error&&<p>{error}</p>}<p>This starter currently validates cloud login. Inventory, checkout, reports and legacy data migration are not yet included.</p><button className="button secondary" onClick={logout}>Log out</button></section></main>;
}
