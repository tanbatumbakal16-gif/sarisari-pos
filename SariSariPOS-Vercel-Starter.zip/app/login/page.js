 "use client";
import { useState } from "react";
export default function Login() {
  const [username,setUsername]=useState(""); const [password,setPassword]=useState(""); const [msg,setMsg]=useState("");
  async function submit(e){e.preventDefault();setMsg("Signing in…");const r=await fetch("/api/auth/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username,password})});const d=await r.json();if(r.ok)location.href="/dashboard";else setMsg(d.error||"Login failed");}
  return <main className="wrap"><h1>Log in</h1><form className="panel" onSubmit={submit}><label>Username<input autoComplete="username" required value={username} onChange={e=>setUsername(e.target.value)}/></label><label>Password<input type="password" autoComplete="current-password" required value={password} onChange={e=>setPassword(e.target.value)}/></label><button className="button">Log in</button><p role="status">{msg}</p><a href="/">Home</a></form></main>;
}
